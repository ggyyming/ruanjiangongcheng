"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView

from config.data_admin import data_site
from config.views import health

urlpatterns = [
    path("", RedirectView.as_view(pattern_name="items:list"), name="home"),
    path("health/", health, name="health"),
    path("admin/", admin.site.urls),
    path("data/", data_site.urls),
    path("accounts/", include("apps.accounts.urls")),
    path("items/", include("apps.catalog.urls")),
    path("transfers/", include("apps.transfers.urls")),
    path("payments/", include("apps.payments.urls")),
    path("loans/", include("apps.loans.urls")),
]
