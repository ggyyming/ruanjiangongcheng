from django.apps import AppConfig


class LoansConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.loans"
    label = "loans"
    verbose_name = "借用、争议与通知"

    def ready(self):
        from . import signals  # noqa: F401
