# 工程架构

## 当前决策

- 使用 Python 3.13 和 Django 5.2 LTS。
- 开发阶段使用 SQLite，降低环境配置成本。
- 使用 uv 管理 Python、虚拟环境、依赖和锁文件。
- 使用 Ruff 统一代码检查和格式。
- 在仓库根目录使用 `AGENTS.md` 约束智能体的修改范围和验证方式。

## 分层与目录

```text
ruanjiangongcheng/
├─ AGENTS.md
├─ README.md
├─ pyproject.toml
├─ uv.lock
├─ manage.py
├─ config/             # Django 全局配置
├─ apps/               # 当前整合版的业务应用
├─ docs/               # 需求与设计文档
└─ .venv/              # 本地环境，不提交
```

每个业务领域对应 `apps/` 下的一个 Django 应用。模型、表单、视图和路由优先保留在所属应用内；只有出现真实的跨应用复用需求时，才提取公共服务或工具。

当前整合版包含 accounts、catalog、transfers、payments、loans 五个应用。模块入口与历史交接包的位置见[工程索引](../PROJECT_INDEX.md)。跨模块集成测试位于 [tests](../tests/)。

## 演进顺序

1. 明确课程题目、用户角色和核心业务流程。
2. 用用户故事和验收条件固定第一版需求。
3. 设计数据模型和页面流程。
4. 按一个完整业务流程逐步实现，而不是一次创建大量空模块。
5. 为关键业务规则补充测试，再准备部署配置。

SQLite 足以支持本地开发和大多数课程演示。只有出现多人并发、独立部署或教师明确要求时，再迁移到 PostgreSQL。

