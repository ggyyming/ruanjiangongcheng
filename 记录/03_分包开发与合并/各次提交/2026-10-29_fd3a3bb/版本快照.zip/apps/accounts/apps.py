from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = "apps.accounts"
    default_auto_field = "django.db.models.BigAutoField"
    verbose_name = "账号与校内认证"
